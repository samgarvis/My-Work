/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 prettyroad prettyroad.png 
 * Time-stamp: Friday 11/06/2020, 21:50:08
 * 
 * Image Information
 * -----------------
 * prettyroad.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PRETTYROAD_H
#define PRETTYROAD_H

extern const unsigned short prettyroad[38400];
#define PRETTYROAD_SIZE 76800
#define PRETTYROAD_LENGTH 38400
#define PRETTYROAD_WIDTH 240
#define PRETTYROAD_HEIGHT 160

#endif

