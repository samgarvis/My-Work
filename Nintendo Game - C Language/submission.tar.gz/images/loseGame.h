/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 loseGame loseGame.png 
 * Time-stamp: Monday 11/09/2020, 04:12:40
 * 
 * Image Information
 * -----------------
 * loseGame.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSEGAME_H
#define LOSEGAME_H

extern const unsigned short loseGame[38400];
#define LOSEGAME_SIZE 76800
#define LOSEGAME_LENGTH 38400
#define LOSEGAME_WIDTH 240
#define LOSEGAME_HEIGHT 160

#endif

