This game begins with a home screen of a pretty road. If you click the enter button you begin the game.

Throughout the entire game if you click backspace then you can return to the home screen.

In the game, you move your player around and try to touch the far right part of the screen to win.
You have 3 lives, and if you touch a stop sign, you lose a life. Getting to 0 lives is losing the game.