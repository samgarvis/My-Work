/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=16x12 stopsign stopsign.png 
 * Time-stamp: Sunday 11/08/2020, 22:50:21
 * 
 * Image Information
 * -----------------
 * stopsign.png 16@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STOPSIGN_H
#define STOPSIGN_H

extern const unsigned short stopsign[192];
#define STOPSIGN_SIZE 384
#define STOPSIGN_LENGTH 192
#define STOPSIGN_WIDTH 16
#define STOPSIGN_HEIGHT 12

#endif

