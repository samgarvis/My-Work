/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=19x14 runningman runningman.png 
 * Time-stamp: Sunday 11/08/2020, 22:56:39
 * 
 * Image Information
 * -----------------
 * runningman.png 19@14
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RUNNINGMAN_H
#define RUNNINGMAN_H

extern const unsigned short runningman[266];
#define RUNNINGMAN_SIZE 532
#define RUNNINGMAN_LENGTH 266
#define RUNNINGMAN_WIDTH 19
#define RUNNINGMAN_HEIGHT 14

#endif

