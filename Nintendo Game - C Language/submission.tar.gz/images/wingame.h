/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 wingame wingame.png 
 * Time-stamp: Monday 11/09/2020, 17:32:01
 * 
 * Image Information
 * -----------------
 * wingame.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINGAME_H
#define WINGAME_H

extern const unsigned short wingame[38400];
#define WINGAME_SIZE 76800
#define WINGAME_LENGTH 38400
#define WINGAME_WIDTH 240
#define WINGAME_HEIGHT 160

#endif

